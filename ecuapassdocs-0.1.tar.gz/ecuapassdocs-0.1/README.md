# ecuapassdocs
Package for creating PDFs, loading resources withing package, and for extracting data from fields in ECUAPASS docs: "cartaportes", "manifiestos", and "declaraciones".

Information is extracted according to the specific company document. Currently, the supported companies are: BYZA, NTA, SYTSA, BOTERO, and SILOGISTICA.
